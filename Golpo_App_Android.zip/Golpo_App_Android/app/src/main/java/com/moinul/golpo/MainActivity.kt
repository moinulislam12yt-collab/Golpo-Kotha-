package com.moinul.golpo

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Story(val title: String, val category: String, val text: String)

class MainActivity : AppCompatActivity() {
    private val stories = listOf(
        Story("শেষ বিকেলের চিঠি", "রোমান্টিক", "বিকেলের শেষ আলোয় সে একটি চিঠি হাতে নিয়ে দাঁড়িয়ে ছিল। চিঠির প্রতিটি শব্দে লুকিয়ে ছিল অপেক্ষা, অভিমান আর ভালোবাসা।"),
        Story("তোমাকে হারানোর ভয়", "আবেগের", "কখনো কখনো মানুষ কাছে থেকেও দূরে চলে যায়। তাই ভালোবাসার মানুষটিকে প্রতিদিন নতুন করে যত্ন করতে হয়।"),
        Story("এক মুঠো স্বপ্ন", "অনুপ্রেরণা", "ছোট্ট একটি স্বপ্ন নিয়েই ছেলেটি পথ চলা শুরু করেছিল। অনেক বাধা এলেও সে থামেনি। একদিন সেই স্বপ্নই তার জীবনের সবচেয়ে সুন্দর বাস্তবতা হয়ে উঠল।"),
        Story("নিশুতি রাত", "ভৌতিক", "রাত বারোটার পর পুরোনো বাড়িটির জানালায় প্রতিদিন একটি আলো জ্বলত। গ্রামের সবাই জানত, সেই ঘরে বহু বছর কেউ থাকে না।")
    )

    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.storyContainer)

        renderStories(stories)

        findViewById<EditText>(R.id.searchBox).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim()?.lowercase() ?: ""
                renderStories(stories.filter {
                    it.title.lowercase().contains(q) || it.category.lowercase().contains(q)
                })
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        findViewById<Button>(R.id.writeButton).setOnClickListener { showStoryWriter() }
    }

    private fun renderStories(list: List<Story>) {
        container.removeAllViews()
        list.forEach { story ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(18, 18, 18, 18)
                background = getDrawable(R.drawable.card_bg)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 0, 0, 14)
                layoutParams = lp
            }

            val title = TextView(this).apply {
                text = story.title
                textSize = 20f
                setTextColor(0xFF211A2D.toInt())
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val cat = TextView(this).apply {
                text = "• ${story.category}"
                textSize = 13f
                setTextColor(0xFF7C4DFF.toInt())
                setPadding(0, 5, 0, 8)
            }
            val preview = TextView(this).apply {
                text = story.text
                textSize = 15f
                setTextColor(0xFF625D68.toInt())
                maxLines = 3
            }

            card.addView(title)
            card.addView(cat)
            card.addView(preview)
            card.setOnClickListener { showStory(story) }
            container.addView(card)
        }
    }

    private fun showStory(story: Story) {
        AlertDialog.Builder(this)
            .setTitle(story.title)
            .setMessage(story.text)
            .setPositiveButton("বন্ধ করুন", null)
            .setNeutralButton("♡ পছন্দ", null)
            .show()
    }

    private fun showStoryWriter() {
        val input = EditText(this).apply {
            hint = "যেমন: একটি কষ্টের প্রেমের গল্প"
            setPadding(30, 10, 30, 10)
        }
        AlertDialog.Builder(this)
            .setTitle("✍️ অটোমেটিক গল্প লেখক")
            .setMessage("তুমি কী ধরনের গল্প চাও লিখে দাও:")
            .setView(input)
            .setNegativeButton("বাতিল", null)
            .setPositiveButton("গল্প তৈরি করুন") { _, _ ->
                val topic = input.text.toString().ifBlank { "একটি সুন্দর গল্প" }
                val generated = "“$topic”\n\nএকদিন এক নীরব বিকেলে গল্পটির শুরু হলো। কিছু মানুষ জীবনে আসে, কিছু স্মৃতি রেখে যায়, আর কিছু অনুভূতি সারাজীবন থেকে যায়। এই গল্পটিও তেমনই এক অনুভূতির কথা—যেখানে আশা, ভালোবাসা আর স্বপ্ন একসঙ্গে পথ চলেছে।\n\nএটি এখন একটি ডেমো গল্প। পরবর্তী ভার্সনে AI যুক্ত করলে তোমার দেওয়া বিষয় অনুযায়ী সম্পূর্ণ নতুন গল্প স্বয়ংক্রিয়ভাবে তৈরি হবে।"
                AlertDialog.Builder(this)
                    .setTitle("তোমার গল্প ✨")
                    .setMessage(generated)
                    .setPositiveButton("ঠিক আছে", null)
                    .show()
            }
            .show()
    }
}
